package dao;

import beans.produto;
import conexao.conexao;
import java.sql.Connection;
import java.sql. PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO {
private conexao conexao;
private conexao conn;

public ProdutoDAO(){
this.conexao = new conexao();
this.conn = this.conexao.getConexao();
}
}
public void inserir(Produto produto){
String sql = "Insert INTO produto (id,nome,peso,cor) VALUES (?,?,?) ";

try{

PreparedStatemement stmt = this.conn.prepareStatement(sql);
stmt.setInt(1, produto.getId()); 
stmt.setString(2, produto.getNome());
stmt.setString(3, produto.getPeso());
stmt.setString(4, produto.getCor());
stmt.execute();

} catch(Exception e){
System.out.println("erro ao inserir produto: "+ e.getMessage());

}
}
public void alterar(Produto produto){
String sql = "UPDATE produto SET id=?, nome=?, peso=?, cor=? WHERE id=?";
try{
preparedStatement stmt = this.conn.prepareStatement(sql);
stmt.setInt(1, produto.getId());
stmt.setString(2, produto.getNome());
stmt.setString(3, produto.getPeso());
stmt.setString(4, produto.getCor());
stmt.execute();
}catch(Exception e) {
Systeem.out.println("Erro ao atualizar produto: ")+ e.getMessage());
}
}
public void excluir(int id){
String sql = "DELETE FROM produto WHERE id = ?";
try{
PreparedStatement stmt = this.conn.preparestatement(sql);
stmt.setInt(1,id);
stmt.execute();
}catch(Exception e){
System.out.println("Erro ao excluir produto: "+ e.getMessage());
}
}
public Produto getProduto(int id){
String sql = "SELECT * FROM produto WHERE id =?";

try{preparedStatement stmt = this.conn.prepareStatement(sql);
stmt.setInt(1, id);
ResultSet rs = stmt.executeQuery();
produto produto = new produto();
rs.next();
produto.setId(rs.getInt("id"));
produto.setNome(rs.getString("nome"));
produto.setPeso(rs.getString("peso"));
produto.setCor(rs.getString("cor"));
return produto;
}catch(Exception e){
System.out.println("Erro ao atualizar produto: "+ e.getMessage());
return null;
}
}
public List<produto> getProduto(){
String sql = "SELECT * FROM produto";
try{
PreparedStatement stmt = this.conn.prepareStatement(sql);
ResultSet rs = stmt.executeQuery();
List<Produto> listaProduto = new ArrayList<>();
while(rs.next()){
Produto p = new Produto ();
p.setId(rs.getInt("id"));
p.setNome(rs.getString("nome"));
p.setPeso(rs.getString("peso"));
p.setCor(rs.getString("cor"));
listaProduto.add(p);
}
return listaProduto;
}catch(Exception e) {
return null;
}
}

