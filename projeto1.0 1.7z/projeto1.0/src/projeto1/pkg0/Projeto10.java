
package projeto1.pkg0;

import conexao.conexao;

public class Projeto10 {

    public static void main(String[] args) {
    try {
        conexao a = new conexao();
        a.getConexao();
        System.out.println("Conectado com sucesso");
    } catch (Exception e) {
        System.out.println("Não conectado");
    }
    }
}
  
