package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class conexao {
    public Connection getConexao(){
       try {
           return DriverManager.getConnection("jdbc:mysql://localhost:3306/animais", "root", "");
       } catch(SQLException e) {
           JOptionPane.showMessageDialog(null, "Erro de conexao");
           return null;
       }
       }
}
