
package beans;

public class produto {
private int id;
private String nome;
private int peso;
private double cor;

public int getid() {
return id; 

}

public void setId(int id) {
this.id = id;

}

public String getNome() {
return nome;    

}

public void setNome(String nome) {
this.nome = nome;    
}

public int getPeso() {
return peso;
}

public void setPeso(int peso) {
this.peso = peso;    
}

public double getCor() {
return cor;    
}

public void setcor(int cor) {
this.cor = cor;    
}

